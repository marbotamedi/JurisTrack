<!-- Template para tarefa individual -->
# {{ID}} - {{TITULO}}

## Objetivo
- {{OBJETIVO}}

## Escopo / Entregáveis
- {{ENTREGAVEIS}}

## Passos e subtarefas
- {{PASSOS}}

## Dependências
- {{DEPENDENCIAS}}

## Paralelizável?
- {{PARALELIZAVEL}} (se sim, com quais tarefas pode rodar em paralelo)

## Critérios de aceite
- {{ACEITE}}

## Testes
- {{TESTES}}

## Notas
- {{NOTAS}}

